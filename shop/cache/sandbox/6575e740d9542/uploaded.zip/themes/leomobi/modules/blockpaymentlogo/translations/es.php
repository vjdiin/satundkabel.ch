<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_bbbd74a260217265015b9c8ff13b903e'] = 'Bloque de logos de pago.';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_3fd11fa0ede1bd0ace9b3fcdbf6a71c9'] = 'Agrega un bloque que muestra todos los logos de pago.';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_b15e7271053fe9dd22d80db100179085'] = 'Este módulo requiere estar enganchado a una columna y su tema no tiene implementada ninguna';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_efc226b17e0532afff43be870bff0de7'] = 'Parámetros actualizados';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_5c5e5371da7ab2c28d1af066a1a1cc0d'] = 'Página CMS no disponible';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_f4f70727dc34561dfde1a3c529b6205c'] = 'Ajustes';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_829cb250498661a9f98a58dc670a9675'] = 'Página de destino para el bloque de enlaces';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
