<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockfacebook}leomobi>blockfacebook_06d770829707bb481258791ca979bd2a'] = 'كتلة الفيسبوك';
$_MODULE['<{blockfacebook}leomobi>blockfacebook_f66e16efd2f1f43944e835aa527f9da8'] = 'يعرض كتلة للاشتراك في الصفحة الفيسبوك الخاص بك.';
$_MODULE['<{blockfacebook}leomobi>blockfacebook_20015706a8cbd457cbb6ea3e7d5dc9b3'] = 'تحديث التكوين';
$_MODULE['<{blockfacebook}leomobi>blockfacebook_f4f70727dc34561dfde1a3c529b6205c'] = 'الإعدادات';
$_MODULE['<{blockfacebook}leomobi>blockfacebook_c98cf18081245e342d7929c117066f0b'] = 'الفيسبوك الرابط (URL الكامل مطلوب)';
$_MODULE['<{blockfacebook}leomobi>blockfacebook_c9cc8cce247e49bae79f15173ce97354'] = 'حفظ';
$_MODULE['<{blockfacebook}leomobi>blockfacebook_a4aa9244ea53b5d916dfd8f024d11e22'] = 'تابعونا في الفيسبوك';
$_MODULE['<{blockfacebook}leomobi>preview_a4aa9244ea53b5d916dfd8f024d11e22'] = 'تابعونا في الفيسبوك';
