<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbanner}leomobi>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Баннер блок';
$_MODULE['<{blockbanner}leomobi>blockbanner_9d9becee392c0fbcc66ff4981b8ae2f7'] = 'Отображает баннер в верхней части магазина.';
$_MODULE['<{blockbanner}leomobi>blockbanner_126b21ce46c39d12c24058791a236777'] = 'Недопустимый формат изображения';
$_MODULE['<{blockbanner}leomobi>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'ошибка при загрузке файла';
$_MODULE['<{blockbanner}leomobi>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'Настройки обновлены';
$_MODULE['<{blockbanner}leomobi>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{blockbanner}leomobi>blockbanner_89ca5c48bbc6b7a648a5c1996767484c'] = 'Блок изображение';
$_MODULE['<{blockbanner}leomobi>blockbanner_4c94cde88098f07d966c2800e050dd67'] = 'Вы можете либо загрузить изображение или дает абсолютную ссылку ниже в опции.';
$_MODULE['<{blockbanner}leomobi>blockbanner_3013dc3fd5a9212be1495367fe0fb8d2'] = 'Ссылка на изображение';
$_MODULE['<{blockbanner}leomobi>blockbanner_ef0b5453792908ee4c0153857da7a895'] = 'Вы можете либо дать абсолютную ссылку на изображение или загрузить изображение в опции выше.';
$_MODULE['<{blockbanner}leomobi>blockbanner_18f2ae2bda9a34f06975d5c124643168'] = 'Описание изображения';
$_MODULE['<{blockbanner}leomobi>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Пожалуйста, введите короткий, но значимое описание для баннера.';
$_MODULE['<{blockbanner}leomobi>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Экономить';
