<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockmanufacturer}leomobi>blockmanufacturer_bc3e73cfa718a3237fb1d7e1da491395'] = 'Блок производителей';
$_MODULE['<{blockmanufacturer}leomobi>blockmanufacturer_71087c7035e626bd33c72ae9a7f042af'] = 'Отображает блок производителей/брендов';
$_MODULE['<{blockmanufacturer}leomobi>blockmanufacturer_b15e7271053fe9dd22d80db100179085'] = 'Этот модуль должны быть подключены в колонну и ваша тема не реализует один';
$_MODULE['<{blockmanufacturer}leomobi>blockmanufacturer_f8c922e47935b3b76a749334045d61cf'] = 'Существует неверное число элементов.';
$_MODULE['<{blockmanufacturer}leomobi>blockmanufacturer_5b2e13ff6fa0da895d14bd56f2cb2d2d'] = 'Пожалуйста, включите хотя бы один способ отображения.';
$_MODULE['<{blockmanufacturer}leomobi>blockmanufacturer_f38f5974cdc23279ffe6d203641a8bdf'] = 'Настройки обновлены.';
$_MODULE['<{blockmanufacturer}leomobi>blockmanufacturer_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{blockmanufacturer}leomobi>blockmanufacturer_bfdff752293014f11f17122c92909ad5'] = 'Использовать текстовый список';
$_MODULE['<{blockmanufacturer}leomobi>blockmanufacturer_a7c6946ecc7f4ed19c2691a1e7a28f97'] = 'Дисплей производителей в текстовом списке.';
$_MODULE['<{blockmanufacturer}leomobi>blockmanufacturer_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Включено';
$_MODULE['<{blockmanufacturer}leomobi>blockmanufacturer_b9f5c797ebbf55adccdd8539a65a0241'] = 'Инвалид';
$_MODULE['<{blockmanufacturer}leomobi>blockmanufacturer_2eef734f174a02ae3d7aaafefeeedb42'] = 'Количество элементами для отображения';
$_MODULE['<{blockmanufacturer}leomobi>blockmanufacturer_b0fa976774d2acf72f9c62e9ab73de38'] = 'Использовать выпадающий список';
$_MODULE['<{blockmanufacturer}leomobi>blockmanufacturer_56353167778d1520bfecc70c470e6d8a'] = 'Для отображения производителей в выпадающем списке';
$_MODULE['<{blockmanufacturer}leomobi>blockmanufacturer_c9cc8cce247e49bae79f15173ce97354'] = 'Экономить';
$_MODULE['<{blockmanufacturer}leomobi>blockmanufacturer_2377be3c2ad9b435ba277a73f0f1ca76'] = 'Производители';
$_MODULE['<{blockmanufacturer}leomobi>blockmanufacturer_c70ad5f80e4c6f299013e08cabc980df'] = 'Подробнее о %s';
$_MODULE['<{blockmanufacturer}leomobi>blockmanufacturer_bf24faeb13210b5a703f3ccef792b000'] = 'Все производители';
$_MODULE['<{blockmanufacturer}leomobi>blockmanufacturer_1c407c118b89fa6feaae6b0af5fc0970'] = 'Нет производителей';
