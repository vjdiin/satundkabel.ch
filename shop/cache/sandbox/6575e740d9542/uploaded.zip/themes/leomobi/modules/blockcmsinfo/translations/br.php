<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_988659f6c5d3210a3f085ecfecccf5d3'] = 'Bloco de CMS personalizado';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_cd4abd29bdc076fb8fabef674039cd6e'] = 'Adiciona um Bloco de informações personalizado na sua loja.';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_d52eaeff31af37a4a7e0550008aff5df'] = 'Ocorreu um erro durante a gravação';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_0366c7b2ea1bb228cd44aec7e3e26a3e'] = 'Configurações atualizadas.';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_6f16c729fadd8aa164c6c47853983dd2'] = 'Novo bloco CMS personalizado';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Textos';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_c9cc8cce247e49bae79f15173ce97354'] = 'Salvar';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_630f6dc397fe74e52d5189e2c80f282b'] = 'Voltar à lista';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_b27f049e3f0863e4de1ee11cc097e3e8'] = 'Número  do bloco personalizado';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_e37b3353531668677ce46e721322803e'] = 'Bloco de texto personalizada';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_ef61fb324d729c341ea8ab9901e23566'] = 'Adicionar novo';
