<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_988659f6c5d3210a3f085ecfecccf5d3'] = 'Blocco di informazioni personalizzate CMS';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_cd4abd29bdc076fb8fabef674039cd6e'] = 'Aggiunge blocchi di informazioni personalizzate nel tuo negozio.';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_d52eaeff31af37a4a7e0550008aff5df'] = 'Errore durante il salvataggio.';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_0366c7b2ea1bb228cd44aec7e3e26a3e'] = 'Configurazione aggiornata.';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_6f16c729fadd8aa164c6c47853983dd2'] = 'Blocco CMS New personalizzato';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Testo';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_c9cc8cce247e49bae79f15173ce97354'] = 'Salvare';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_630f6dc397fe74e52d5189e2c80f282b'] = 'Torna alla lista';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_b27f049e3f0863e4de1ee11cc097e3e8'] = 'Numero di blocco personalizzato';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_e37b3353531668677ce46e721322803e'] = 'Blocco di testo personalizzato';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_23498d91b6017e5d7f4ddde70daba286'] = 'ID negozio';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_ef61fb324d729c341ea8ab9901e23566'] = 'Aggiungi nuovo';
