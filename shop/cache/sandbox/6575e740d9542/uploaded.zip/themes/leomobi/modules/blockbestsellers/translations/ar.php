<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers-home_3cb29f0ccc5fd220a97df89dafe46290'] = 'الأكثر مبيعاً';
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers-home_d3da97e2d9aee5c8fbe03156ad051c99'] = 'مشاهدة المزيد';
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers-home_4351cfebe4b61d8aa5efa1d020710005'] = 'عرض';
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers-home_eae99cd6a931f3553123420b16383812'] = 'جميع الكتب مبيعا';
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers-home_adc570b472f54d65d3b90b8cee8368a9'] = 'لا يوجد منتجات أكثر مبيعاً';
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers_9862f1949f776f69155b6e6b330c7ee1'] = 'الباعة من أعلى إلى منع';
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers_ed6476843a865d9daf92e409082b76e1'] = 'ويضيف كتلة عرض متجرك المنتجات الأكثر مبيعا.';
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers_b15e7271053fe9dd22d80db100179085'] = 'هذه الوحدة تحتاج إلى أن يكون مدمن مخدرات في عمود والموضوع الخاص بك لا يقوم واحد';
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers_c888438d14855d7d96a2724ee9c306bd'] = 'الإعدادات المحدثة';
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers_f4f70727dc34561dfde1a3c529b6205c'] = 'الإعدادات';
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers_24ff4e4d39bb7811f6bdf0c189462272'] = 'عرض كتلة دائما';
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers_84b0c5fdef19ab8ef61cd809f9250d85'] = 'تظهر كتلة حتى لو لم مبيعا المتاحة.';
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'مفعل';
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers_b9f5c797ebbf55adccdd8539a65a0241'] = 'غير مفعل';
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers_c9cc8cce247e49bae79f15173ce97354'] = 'حفظ';
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers_1d0a2e1f62ccf460d604ccbc9e09da95'] = 'عرض المنتجات الأكثر مبيعا';
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers_3cb29f0ccc5fd220a97df89dafe46290'] = 'الأكثر مبيعاً';
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers_eae99cd6a931f3553123420b16383812'] = 'جميع الكتب مبيعا';
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers_f7be84d6809317a6eb0ff3823a936800'] = 'لا توجد منتجات أكثر مبيعاً في هذا الوقت';
$_MODULE['<{blockbestsellers}leomobi>tab_d7b2933ba512ada478c97fa43dd7ebe6'] = 'الأكثر مبيعاً';
$_MODULE['<{blockbestsellers}leomobi>blockbestsellers-home_09a5fe24fe0fc9ce90efc4aa507c66e7'] = 'لا أفضل الكتب مبيعا في هذا الوقت.';
