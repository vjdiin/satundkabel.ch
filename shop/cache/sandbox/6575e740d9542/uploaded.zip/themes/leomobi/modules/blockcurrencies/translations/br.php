<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcurrencies}leomobi>blockcurrencies_f7a31ae8f776597d4282bd3b1013f08b'] = 'Bloco de moedas';
$_MODULE['<{blockcurrencies}leomobi>blockcurrencies_80ed40ee905b534ee85ce49a54380107'] = 'Adiciona um bloco para seleção de moeda.';
$_MODULE['<{blockcurrencies}leomobi>blockcurrencies_386c339d37e737a436499d423a77df0c'] = 'Moeda';
