<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_988659f6c5d3210a3f085ecfecccf5d3'] = 'Własny blok informacyjny CMS';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_cd4abd29bdc076fb8fabef674039cd6e'] = 'Dodaje bloki z własną informacją w Twoim sklepie.';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_d52eaeff31af37a4a7e0550008aff5df'] = 'Wystąpił błąd podczas próby zapisu.';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_0366c7b2ea1bb228cd44aec7e3e26a3e'] = 'Konfiguracja bloku została zaktualizowana.';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_6f16c729fadd8aa164c6c47853983dd2'] = 'Nowy własny blok CMS';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Tekst';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_c9cc8cce247e49bae79f15173ce97354'] = 'Oszczędzać';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_630f6dc397fe74e52d5189e2c80f282b'] = 'Powrót do listy';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_b27f049e3f0863e4de1ee11cc097e3e8'] = 'Własny numer bloku';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_e37b3353531668677ce46e721322803e'] = 'Niestandardowy blok tekstu';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_23498d91b6017e5d7f4ddde70daba286'] = 'ID Sklepu';
$_MODULE['<{blockcmsinfo}leomobi>blockcmsinfo_ef61fb324d729c341ea8ab9901e23566'] = 'Dodaj nowy';
