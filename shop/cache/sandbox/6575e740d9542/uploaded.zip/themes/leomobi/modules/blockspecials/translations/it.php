<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockspecials}leomobi>blockspecials_c19ed4ea98cbf319735f6d09bde6c757'] = 'Blocco offerte speciali';
$_MODULE['<{blockspecials}leomobi>blockspecials_f5bae06098deb9298cb9ceca89171944'] = 'Aggiunge un blocco di visualizzazione dei vostri prodotti scontati attuali.';
$_MODULE['<{blockspecials}leomobi>blockspecials_b15e7271053fe9dd22d80db100179085'] = 'Questo modulo ha bisogno di essere agganciato in una colonna e il tema non implementa uno';
$_MODULE['<{blockspecials}leomobi>blockspecials_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornati';
$_MODULE['<{blockspecials}leomobi>blockspecials_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blockspecials}leomobi>blockspecials_24ff4e4d39bb7811f6bdf0c189462272'] = 'Visualizzare sempre questo blocco';
$_MODULE['<{blockspecials}leomobi>blockspecials_53d61d1ac0507b1bd8cd99db8d64fb19'] = 'Mostra il blocco anche se nessun prodotto è disponibile.';
$_MODULE['<{blockspecials}leomobi>blockspecials_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Attivato';
$_MODULE['<{blockspecials}leomobi>blockspecials_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabile';
$_MODULE['<{blockspecials}leomobi>blockspecials_61465481ac2491b37e4517960bbd4a14'] = 'Numero di file memorizzati nella cache';
$_MODULE['<{blockspecials}leomobi>blockspecials_e80a11f1704b88ad50f8fc6ce0f43525'] = 'Speciali vengono visualizzati in modo casuale sul front-end, ma dal momento che ci vuole un sacco di ressources, è meglio mettere in cache i risultati. La cache viene azzerato ogni giorno. 0 disabilita la cache.';
$_MODULE['<{blockspecials}leomobi>blockspecials_c9cc8cce247e49bae79f15173ce97354'] = 'Salvare';
$_MODULE['<{blockspecials}leomobi>blockspecials_d1aa22a3126f04664e0fe3f598994014'] = 'Speciali';
$_MODULE['<{blockspecials}leomobi>blockspecials_b4f95c1ea534936cc60c6368c225f480'] = 'Tutte le offerte speciali';
$_MODULE['<{blockspecials}leomobi>blockspecials_3c9f5a6dc6585f75042bd4242c020081'] = 'Non ci sono offerte speciali in questo momento.';
