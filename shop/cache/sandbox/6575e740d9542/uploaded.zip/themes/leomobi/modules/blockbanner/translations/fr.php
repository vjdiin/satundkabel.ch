<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbanner}leomobi>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Bloc bannière';
$_MODULE['<{blockbanner}leomobi>blockbanner_9d9becee392c0fbcc66ff4981b8ae2f7'] = 'Permet d\'afficher une bannière dans l\'en-tête du site.';
$_MODULE['<{blockbanner}leomobi>blockbanner_126b21ce46c39d12c24058791a236777'] = 'image non valable';
$_MODULE['<{blockbanner}leomobi>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'une erreur s\'est produite lors de l\'envoi';
$_MODULE['<{blockbanner}leomobi>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'Paramètres mis à jour';
$_MODULE['<{blockbanner}leomobi>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Paramètres';
$_MODULE['<{blockbanner}leomobi>blockbanner_89ca5c48bbc6b7a648a5c1996767484c'] = 'Image';
$_MODULE['<{blockbanner}leomobi>blockbanner_296dce46079fc6cabe69b7e7edb25506'] = 'You can either upload the image file, or enter its absolute link in the \"Image link\" option below';
$_MODULE['<{blockbanner}leomobi>blockbanner_9ce38727cff004a058021a6c7351a74a'] = 'Image link';
$_MODULE['<{blockbanner}leomobi>blockbanner_5b79f7f033924a348f025924820988cb'] = 'You can either upload the image file, or enter its absolute link in the \"Image link\" option below';
$_MODULE['<{blockbanner}leomobi>blockbanner_18f2ae2bda9a34f06975d5c124643168'] = 'Description de l\'image';
$_MODULE['<{blockbanner}leomobi>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Veuillez saisir une description courte mais précise pour votre bannière.';
$_MODULE['<{blockbanner}leomobi>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
