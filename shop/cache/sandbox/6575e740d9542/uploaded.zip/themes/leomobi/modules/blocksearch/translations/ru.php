<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksearch}leomobi>blocksearch-top_13348442cc6a27032d2b4aa28b75a5d3'] = 'Поиск';
$_MODULE['<{blocksearch}leomobi>blocksearch_e2ca130372651672ba285abd796412ed'] = 'Блок быстрого поиска';
$_MODULE['<{blocksearch}leomobi>blocksearch_be305c865235f417d9b4d22fcdf9f1c5'] = 'Добавляет блок с полем быстрого поиска.';
$_MODULE['<{blocksearch}leomobi>blocksearch_13348442cc6a27032d2b4aa28b75a5d3'] = 'Поиск';
$_MODULE['<{blocksearch}leomobi>blocksearch_ce1b00a24b52e74de46971b174d2aaa6'] = 'Поиск товаров:';
$_MODULE['<{blocksearch}leomobi>blocksearch_5f075ae3e1f9d0382bb8c4632991f96f'] = 'Идти';
