<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_bbbd74a260217265015b9c8ff13b903e'] = 'Block Zahlungslogos';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_3fd11fa0ede1bd0ace9b3fcdbf6a71c9'] = 'Fügt einen Block mit allen Zahlungslogos hinzu';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_b15e7271053fe9dd22d80db100179085'] = 'Dieses Modul benötigen, um in einer Spalte eingehängt werden und Ihr Thema nicht ein implementieren';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_efc226b17e0532afff43be870bff0de7'] = 'Die Einstellungen wurden aktualisiert.';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_5c5e5371da7ab2c28d1af066a1a1cc0d'] = 'Keine CMS-Seite verfügbar';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_829cb250498661a9f98a58dc670a9675'] = 'Zielseite für Block-Link';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
