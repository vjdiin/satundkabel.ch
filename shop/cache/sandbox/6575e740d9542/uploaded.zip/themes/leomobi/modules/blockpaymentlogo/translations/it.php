<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_bbbd74a260217265015b9c8ff13b903e'] = 'Loghi di pagamento bloccano.';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_3fd11fa0ede1bd0ace9b3fcdbf6a71c9'] = 'Aggiunge un blocco che visualizza tutti i marchi di pagamento.';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_b15e7271053fe9dd22d80db100179085'] = 'Questo modulo ha bisogno di essere agganciato in una colonna e il tema non implementa uno';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_efc226b17e0532afff43be870bff0de7'] = 'Le impostazioni sono state aggiornate.';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_5c5e5371da7ab2c28d1af066a1a1cc0d'] = 'Nessuna pagina CMS è disponibile.';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_829cb250498661a9f98a58dc670a9675'] = 'Pagina di destinazione per il collegamento del blocco';
$_MODULE['<{blockpaymentlogo}leomobi>blockpaymentlogo_c9cc8cce247e49bae79f15173ce97354'] = 'Salvare';
