<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbanner}leomobi>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Block Banner';
$_MODULE['<{blockbanner}leomobi>blockbanner_9d9becee392c0fbcc66ff4981b8ae2f7'] = 'Banner im Kopfteil des Shops anzeigen.';
$_MODULE['<{blockbanner}leomobi>blockbanner_126b21ce46c39d12c24058791a236777'] = 'Bild ungültig';
$_MODULE['<{blockbanner}leomobi>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'Fehler beim Upload der Datei';
$_MODULE['<{blockbanner}leomobi>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'Einstellungen wurden aktualisiert.';
$_MODULE['<{blockbanner}leomobi>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blockbanner}leomobi>blockbanner_89ca5c48bbc6b7a648a5c1996767484c'] = 'Blocklogo';
$_MODULE['<{blockbanner}leomobi>blockbanner_4c94cde88098f07d966c2800e050dd67'] = 'Wählen Sie entweder ein Bild zum Upload oder geben Sie die URL des Bildes im folgenden Feld ein.';
$_MODULE['<{blockbanner}leomobi>blockbanner_3013dc3fd5a9212be1495367fe0fb8d2'] = 'Bild-Link';
$_MODULE['<{blockbanner}leomobi>blockbanner_ef0b5453792908ee4c0153857da7a895'] = 'Wählen Sie entweder ein Bild zum Upload oder geben Sie die URL des Bildes im folgenden Feld ein.';
$_MODULE['<{blockbanner}leomobi>blockbanner_18f2ae2bda9a34f06975d5c124643168'] = 'Beschreibung';
$_MODULE['<{blockbanner}leomobi>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Bitte geben Sie eine kurze, treffende Bescheibung für das Banner ein.';
$_MODULE['<{blockbanner}leomobi>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
