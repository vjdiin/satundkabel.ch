<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksearch}leomobi>blocksearch-top_13348442cc6a27032d2b4aa28b75a5d3'] = 'Suche';
$_MODULE['<{blocksearch}leomobi>blocksearch_e2ca130372651672ba285abd796412ed'] = 'Block Schnellsuche';
$_MODULE['<{blocksearch}leomobi>blocksearch_be305c865235f417d9b4d22fcdf9f1c5'] = 'Fügt einen Block mit einem Quick Search Feld hinzu';
$_MODULE['<{blocksearch}leomobi>blocksearch_13348442cc6a27032d2b4aa28b75a5d3'] = 'Suche';
$_MODULE['<{blocksearch}leomobi>blocksearch_ce1b00a24b52e74de46971b174d2aaa6'] = 'Produkte suchen';
$_MODULE['<{blocksearch}leomobi>blocksearch_5f075ae3e1f9d0382bb8c4632991f96f'] = 'Go';
